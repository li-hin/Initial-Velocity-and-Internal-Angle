#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::getInput()
{
    initialSpeed = ui->spinBox->value(); // m/s
    launchAngleDegrees = ui->spinBox_2->value(); // degrees
}

void MainWindow::calculate()
{
    // Convert degrees to radians for standard C++ math functions (sin, cos)
    const double PI = 3.14159265358979323846;
    double launchAngleRadians = launchAngleDegrees * (PI / 180.0);
    double t = 0.0;
    Point2D currentPos;

    // Loop while the bullet is above the ground (y >= 0)
    do {
        currentPos = calculatePosition(initialSpeed, launchAngleRadians, t, gravity);

        qDebug() << "Time: " << t << "s | ";
        qDebug() << "X Pos: " << currentPos.x << "m | ";
        qDebug() << "Y Pos: " << currentPos.y << "m" ;

        t += timeStep;

        // Safety break if something goes wrong (e.g., negative time step)
        if (t > 100) break;

    } while (currentPos.y >= 0.0 || t < 0.01); // Ensure at least one point is printed

}

MainWindow::Point2D MainWindow::calculatePosition(double initialSpeed, double launchAngleRadians, double timeElapsed, double gravity)
{
    Point2D position;

    position.x = initialSpeed * cos(launchAngleRadians) * timeElapsed;
    position.y = (initialSpeed * sin(launchAngleRadians) * timeElapsed) *

                 (0.5 * gravity * timeElapsed * timeElapsed);
    qDebug() << "in x" << position.x << "in y" << position.y ;


    return position;
}

void MainWindow::on_pushButton_clicked()
{
    getInput();
    calculate();
}


void MainWindow::on_pushButton_2_clicked()
{
    QString text;

    text += "BEGIN\n\n";
    text += "  // --- READ USER INPUT ---\n";
    text += "  READ initialSpeed FROM velocity spinbox\n";
    text += "  READ launchAngleDegrees FROM angle spinbox\n\n";

    text += "  // --- CONVERT ANGLE TO RADIANS ---\n";
    text += "  SET PI = 3.14159\n";
    text += "  SET launchAngleRadians = launchAngleDegrees * (PI / 180)\n\n";

    text += "  // --- INITIALIZE SIMULATION VALUES ---\n";
    text += "  SET time t = 0\n";
    text += "  DEFINE gravity (constant)\n";
    text += "  DEFINE timeStep (constant)\n\n";

    text += "  // --- LOOP WHILE PROJECTILE IS ABOVE GROUND ---\n";
    text += "  DO\n";
    text += "      x = initialSpeed * cos(launchAngleRadians) * t\n";
    text += "      y = initialSpeed * sin(launchAngleRadians) * t - 0.5 * gravity * t^2\n";
    text += "      PRINT time, x, y\n";
    text += "      INCREMENT t by timeStep\n";
    text += "      IF t > 100 THEN BREAK\n";
    text += "  WHILE y >= 0 OR t < 0.01\n\n";
    text += "END\n";

    ui->textBrowser->setText(text);
}

