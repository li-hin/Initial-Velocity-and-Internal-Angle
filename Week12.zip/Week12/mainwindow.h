#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
// #include <math.h>
#include <QDebug>
#include <stdlib.h>
#include <stdio.h>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::MainWindow *ui;
    void getInput();
    void calculate();
    void display();
    struct Point2D {
        double x;
        double y;
    };

    Point2D calculatePosition(double initialSpeed, double launchAngleRadians, double timeElapsed, double gravity = 9.81);
    double initialSpeed = 50.0; // m/s
    double launchAngleDegrees = 45.0; // degrees
    double gravity = 9.81; // m/s^2
    double timeStep = 10; // Calculate position every 0.1 seconds

};
#endif // MAINWINDOW_H
